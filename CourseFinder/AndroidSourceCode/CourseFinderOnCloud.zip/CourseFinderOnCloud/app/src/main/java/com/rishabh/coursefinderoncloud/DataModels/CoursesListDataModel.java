package com.rishabh.coursefinderoncloud.DataModels;

public class CoursesListDataModel {

  private String title, img_url, course_id;

  public CoursesListDataModel(String title, String img_url, String course_id) {
    this.title = title;
    this.img_url = img_url;
    this.course_id = course_id;
  }


  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getImg_url() {
    return img_url;
  }

  public void setImg_url(String img_url) {
    this.img_url = img_url;
  }

  public String getCourse_id() {
    return course_id;
  }

  public void setCourse_id(String course_id) {
    this.course_id = course_id;
  }
}

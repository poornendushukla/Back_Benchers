package com.rishabh.coursefinderoncloud.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rishabh.coursefinderoncloud.DataModels.NukeSSLCerts;
import com.rishabh.coursefinderoncloud.R;
import com.rishabh.coursefinderoncloud.Utils.API;
import gr.net.maroulis.library.EasySplashScreen;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.OkHttpClient.Builder;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class SplashScreenActivity extends AppCompatActivity {

  private static final String url = "http://ec2-3-92-177-31.compute-1.amazonaws.com:3000/";
  public static API api = null; //api variable to be used throughout the app.

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    NukeSSLCerts.nuke();
    final Gson gson = new GsonBuilder()
        .setLenient()
        .create();
    //to set timeOut time of a call.
    OkHttpClient.Builder client = new Builder();
    client.connectTimeout(30, TimeUnit.SECONDS);
    client.readTimeout(2, TimeUnit.MINUTES);
    client.writeTimeout(2, TimeUnit.MINUTES);

    Retrofit retrofit = new Retrofit.Builder()
        .baseUrl(url)
        .client(client.build())
        .addConverterFactory(ScalarsConverterFactory.create())
        .addConverterFactory(GsonConverterFactory.create(gson))
        .build();
    api = retrofit.create(API.class);

    final EasySplashScreen config = new EasySplashScreen(SplashScreenActivity.this)
        .withFullScreen()
        .withSplashTimeOut(2000)
        .withBackgroundResource(android.R.color.white)
        .withAfterLogoText("Programmer Glasses")
        .withFooterText("By:- Back Benchers")
        .withLogo(R.drawable.list_icons);
    Animation shake = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.reveal);
    config.getAfterLogoTextView().setTextSize(22);
    config.getAfterLogoTextView().setTextColor(getResources().getColor(R.color.colorBlack));
    config.getAfterLogoTextView().startAnimation(shake);
    config.getAfterLogoTextView().setPadding(0, 100, 0, 0);
    config.getFooterTextView().setTextSize(16);
    config.getFooterTextView().setTextColor(getResources().getColor(R.color.colorBlack));
    config.getFooterTextView().setPadding(0, 0, 0, 10);
    config.withTargetActivity(LoginActivity.class);
    View view = config.create();
    setContentView(view);
  }


}

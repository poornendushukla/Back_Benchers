package com.rishabh.coursefinderoncloud.Data;

public class Form_data {

  public static String[] interests = {"Data Science", "Web Development", "Programming"};
  public static String[] prerequisites = {
      "Linear Algebra", "Statistics", "Probability", "Scripting Language", "CSS", "HTML4",
      "Bootstrap4", "Node js", "Angular js", "PHP", "DBMS", "Algorithm", "Data Structure", "Other"
  };
}

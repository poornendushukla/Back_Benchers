package com.rishabh.coursefinderoncloud.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.rishabh.coursefinderoncloud.DataModels.VolleySingleton;
import com.rishabh.coursefinderoncloud.R;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewCourseActitvity extends AppCompatActivity {

  String course_id;
  TextView courseName, viaText, instituteText, starsText, descText, balancedRating;
  ImageView imageView, likeBtn, dislikeBtn;
  Button button;
  String likeStatus = "like";
  private String user_name; //user_name of the app user.
  EditText editText;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_view_course_actitvity);
    user_name = PreferenceManager.getDefaultSharedPreferences(this)
        .getString("user_name", "defaultstringifnothingfound");
    Intent intent = getIntent();
    course_id = intent.getStringExtra("course_id");
    ImageView backButton = findViewById(R.id.back_button);
    backButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        ViewCourseActitvity.this.finish();
      }
    });
    courseName = findViewById(R.id.course_name);
    viaText = findViewById(R.id.via);
    instituteText = findViewById(R.id.institute);
    starsText = findViewById(R.id.stars);
    descText = findViewById(R.id.desc);
    imageView = findViewById(R.id.imageView);
    Glide.with(this).load(R.drawable.mooc_icon).into(imageView);
    balancedRating = findViewById(R.id.balanced_rating);
    getData();
    editText = findViewById(R.id.review_text);
    button = findViewById(R.id.link_to_site);
    button.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        if (editText.getText().toString().length() > 0) {
          postReview(editText.getText().toString());
        } else {
          Toast.makeText(ViewCourseActitvity.this, "Empty review", Toast.LENGTH_SHORT).show();
        }
      }
    });
    likeBtn = findViewById(R.id.thumbs_up);
    dislikeBtn = findViewById(R.id.thumbs_down);
    likeBtn.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        likeStatus = "like";
        postLike(likeStatus);
        likeBtn.setEnabled(false);
      }
    });
    dislikeBtn.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        likeStatus = "dislike";
        postLike(likeStatus);
        dislikeBtn.setEnabled(false);
      }
    });
  }


  void postLike(final String likeStatus) {
    String url = "https://sshopr.com/webApp/post_like.php";
    StringRequest stringRequest = new StringRequest(Method.POST, url,
        new Response.Listener<String>() {
          @Override
          public void onResponse(String ServerResponse) {
            Toast.makeText(ViewCourseActitvity.this, ServerResponse, Toast.LENGTH_SHORT).show();
            likeBtn.setEnabled(true);
            dislikeBtn.setEnabled(true);
          }
        },
        new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError volleyError) {
            Toast.makeText(ViewCourseActitvity.this, "Something went wrong", Toast.LENGTH_SHORT)
                .show();
            volleyError.printStackTrace();
          }
        }) {
      @Override
      protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("course_id", course_id);
        params.put("user_id", user_name);
        params.put("like", likeStatus);
        return params;
      }

    };
    VolleySingleton.getInstance(ViewCourseActitvity.this).addToRequestQueue(stringRequest);
  }


  void postReview(final String review) {
    editText.setText("");
    String url = "https://sshopr.com/webApp/post_review.php";
    StringRequest stringRequest = new StringRequest(Method.POST, url,
        new Response.Listener<String>() {
          @Override
          public void onResponse(String ServerResponse) {
            Toast.makeText(ViewCourseActitvity.this, ServerResponse, Toast.LENGTH_SHORT).show();
            if (ServerResponse.equals("liked")) {
              dislikeBtn.setEnabled(true);
            } else if (ServerResponse.equals("disliked")) {
              likeBtn.setEnabled(true);
            }
          }
        },
        new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError volleyError) {
            Toast.makeText(ViewCourseActitvity.this, "Something went wrong", Toast.LENGTH_SHORT)
                .show();
            volleyError.printStackTrace();
          }
        }) {
      @Override
      protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("course_id", course_id);
        params.put("user_id", user_name);
        params.put("review", review);
        return params;
      }

    };
    VolleySingleton.getInstance(ViewCourseActitvity.this).addToRequestQueue(stringRequest);
  }


  private void getData() {
    final ProgressDialog dialog = new ProgressDialog(this);
    dialog.setIndeterminate(true);
    dialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.list_icons));
    dialog.setMessage("Fetching details");
    dialog.setCanceledOnTouchOutside(false);
    dialog.show();
    String url = "https://sshopr.com/webApp/view_course_details.php";
    // Creating string request with post method.
    StringRequest stringRequest = new StringRequest(Method.POST, url,
        new Response.Listener<String>() {
          @Override
          public void onResponse(String ServerResponse) {
            Log.d("response", ServerResponse);
            parseJson(ServerResponse);
            dialog.dismiss();
          }
        },
        new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError volleyError) {
            dialog.dismiss();
            Toast.makeText(ViewCourseActitvity.this, "Something went wrong", Toast.LENGTH_SHORT)
                .show();
            volleyError.printStackTrace();
          }
        }) {
      @Override
      protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("course_id", course_id);
        return params;
      }

    };
    VolleySingleton.getInstance(ViewCourseActitvity.this).addToRequestQueue(stringRequest);
  }


  public void parseJson(String result) {
    try {
      JSONObject jsonObject = new JSONObject(result);
      JSONArray jsonArray = jsonObject.getJSONArray("response");
      int count = 0;
      while (count < jsonArray.length()) {
        final String name, viatext, institutetext, starstext, desctext, link;
        JSONObject JO = jsonArray.getJSONObject(count);
        name = JO.getString("name");
        viatext = JO.getString("author");
        institutetext = JO.getString("institute");
        starstext = JO.getString("rating");
        desctext = JO.getString("desc");
        balancedRating.setText(JO.getString("balanced"));
        link = JO.getString("link");
        courseName.setText(name);
        viaText.setText(viatext);
        instituteText.setText(institutetext);
        starsText.setText(starstext);
        descText.setText(desctext);
        count = count + 1;

      }

    } catch (JSONException e) {
      e.printStackTrace();

    }
  }


}

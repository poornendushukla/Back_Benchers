package com.rishabh.coursefinderoncloud.DataModels;

import java.util.List;

public class CourseDataModel {

  private String name, upvotes, author, course_id, link;
  private List<String> tagslist;

  public CourseDataModel(String name, String upvotes, String author, String course_id,
      String link, List<String> tagslist) {
    this.name = name;
    this.upvotes = upvotes;
    this.author = author;
    this.course_id = course_id;
    this.link = link;
    this.tagslist = tagslist;
  }

  public List<String> getTagslist() {
    return tagslist;
  }

  public void setTagslist(List<String> tagslist) {
    this.tagslist = tagslist;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getUpvotes() {
    return upvotes;
  }

  public void setUpvotes(String upvotes) {
    this.upvotes = upvotes;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public String getCourse_id() {
    return course_id;
  }

  public void setCourse_id(String course_id) {
    this.course_id = course_id;
  }

  public String getLink() {
    return link;
  }

  public void setLink(String link) {
    this.link = link;
  }
}

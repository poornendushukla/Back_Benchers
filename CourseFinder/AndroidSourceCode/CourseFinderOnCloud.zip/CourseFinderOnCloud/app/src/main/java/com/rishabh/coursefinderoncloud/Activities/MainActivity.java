package com.rishabh.coursefinderoncloud.Activities;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.rishabh.coursefinderoncloud.Adapters.CoursesRecyclerViewAdapter;
import com.rishabh.coursefinderoncloud.DataModels.CourseDataModel;
import com.rishabh.coursefinderoncloud.DataModels.VolleySingleton;
import com.rishabh.coursefinderoncloud.R;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

  RecyclerView recyclerView;
  EditText editText;
  CoursesRecyclerViewAdapter adapter;
  private List<CourseDataModel> tileDataModelList = new ArrayList<>();
  public static String filter_value = "balanced_rating";
  public static String language_filter = "English";
  ProgressDialog dialog;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    editText = findViewById(R.id.search_text);
    recyclerView = findViewById(R.id.recyclerView);
    LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
    recyclerView.setLayoutManager(layoutManager);
    adapter = new CoursesRecyclerViewAdapter(tileDataModelList, this);
    recyclerView.setAdapter(adapter);
    editText.addTextChangedListener(new TextWatcher() {
      @Override
      public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

      }

      @Override
      public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

      }

      @Override
      public void afterTextChanged(Editable editable) {
        filter(editable.toString());
      }
    });
    populateList();
  }


  void filter(String text){
    List<CourseDataModel> temp = new ArrayList<>();
    for(CourseDataModel d: tileDataModelList){
      if(d.getName().toLowerCase().contains(text.toLowerCase())){
        temp.add(d);
      }
    }
    adapter.updateList(temp);
    ImageView back_button = findViewById(R.id.back_button);
    back_button.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        MainActivity.this.finish();
      }
    });
  }


  private void populateList() {
    dialog = new ProgressDialog(this);
    dialog.setIndeterminate(true);
    dialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.list_icons));
    dialog.setMessage("Getting you the best courses");
    dialog.setCanceledOnTouchOutside(false);
    String url = "https://sshopr.com/webApp/get_list_of_mooc_courses.php";
    // Creating string request with post method.
    StringRequest stringRequest = new StringRequest(Method.POST, url,
        new Response.Listener<String>() {
          @Override
          public void onResponse(String ServerResponse) {
            Log.d("response", ServerResponse);
            parseJson(ServerResponse);
          }
        },
        new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError volleyError) {
            Toast.makeText(MainActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            volleyError.printStackTrace();
          }
        }) {
      @Override
      protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("subject", "mooc");
        params.put("filter",filter_value);
        params.put("language", language_filter);
        return params;
      }

    };
    VolleySingleton.getInstance(MainActivity.this).addToRequestQueue(stringRequest);

    adapter.notifyDataSetChanged();
  }


  public void parseJson(String result) {
    try {
      JSONObject jsonObject = new JSONObject(result);
      JSONArray jsonArray = jsonObject.getJSONArray("server_response");
      int count = 0;
      while (count < jsonArray.length()) {
        String title, author, upvotes, course_id, tags, link;
        List<String> list = new ArrayList<>();
        JSONObject JO = jsonArray.getJSONObject(count);
        title = JO.getString("name");
        upvotes = JO.getString("upvotes");
        author = JO.getString("author");
        course_id = JO.getString("course_id");
        tags = JO.getString("tagslist");
        link = JO.getString("link");
        CourseDataModel courseDataModel = new CourseDataModel(title, upvotes, author, course_id,link, list);
        tileDataModelList.add(courseDataModel);
        count = count + 1;

      }

    } catch (Exception e) {
      e.printStackTrace();

    }
    dialog.dismiss();
    adapter.notifyDataSetChanged();
  }




}

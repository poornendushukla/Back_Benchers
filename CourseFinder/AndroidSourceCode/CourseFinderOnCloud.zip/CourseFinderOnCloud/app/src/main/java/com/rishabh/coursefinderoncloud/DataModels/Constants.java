package com.rishabh.coursefinderoncloud.DataModels;

public class Constants {

  public static final String GETSUBJECTS = "https://sshopr.com/webApp/get_json_subjects.php";
  public static final String GETCOURSES = "https://sshopr.com/webApp/get_json_courses.php";

}

package com.rishabh.coursefinderoncloud.Adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import com.rishabh.coursefinderoncloud.DataModels.PreRequisiteDataModel;
import com.rishabh.coursefinderoncloud.R;
import java.util.List;

public class PreRequisiteAdapter extends
    RecyclerView.Adapter<PreRequisiteAdapter.ViewHolder> {

  Context context;
  private List<PreRequisiteDataModel> tileDataModelList;

  public PreRequisiteAdapter(List<PreRequisiteDataModel> dataList, Context context) {
    this.tileDataModelList = dataList;
    this.context = context;
    setHasStableIds(true);
  }


  @NonNull
  @Override
  public PreRequisiteAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    //inflate the layout file
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.pre_requisite_selection, parent, false);
    return new PreRequisiteAdapter.ViewHolder(view);
  }


  @Override
  public long getItemId(int position) {
    return position;
  }


  @Override
  public void onBindViewHolder(@NonNull final PreRequisiteAdapter.ViewHolder holder, final int position) {
    final PreRequisiteDataModel model = tileDataModelList.get(position);
    holder.textView.setText(model.getText());
    holder.checkBox.setChecked(model.isStatus());
    holder.checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
      @Override
      public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        model.setStatus(b);
      }
    });
  }


  @Override
  public int getItemCount() {
    return tileDataModelList.size();
  }


  public class ViewHolder extends RecyclerView.ViewHolder {

    CheckBox checkBox;
    TextView textView;

    public ViewHolder(View view) {
      super(view);
      checkBox = view.findViewById(R.id.checkbox);
      textView = view.findViewById(R.id.text);
    }

  }


}


package com.rishabh.coursefinderoncloud.Activities;

import static com.rishabh.coursefinderoncloud.Activities.SplashScreenActivity.api;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.rishabh.coursefinderoncloud.Adapters.PreRequisiteAdapter;
import com.rishabh.coursefinderoncloud.Data.Form_data;
import com.rishabh.coursefinderoncloud.DataModels.PreRequisiteDataModel;
import com.rishabh.coursefinderoncloud.R;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpActivity extends AppCompatActivity {

  ArrayList<String> years = new ArrayList<>();
  ArrayList<String> branches = new ArrayList<>();
  ArrayList<String> interests = new ArrayList<>();
  EditText etName, etUserName, etPassWord, etAge;
  Spinner spinnerYear, spinnerBranch, spinnerInterest;
  RecyclerView recyclerView;
  List<PreRequisiteDataModel> dataModelList = new ArrayList<>();
  PreRequisiteAdapter adapter;
  Button submitButton;
  List<String> prereques = new ArrayList<>();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_sign_up);
    spinnerYear = findViewById(R.id.year_dropdown);
    spinnerBranch = findViewById(R.id.branch_dropdown);
    spinnerInterest = findViewById(R.id.interest_dropdown);
    etName = findViewById(R.id.et_name);
    etUserName = findViewById(R.id.et_user_name);
    etAge = findViewById(R.id.et_user_age);
    etPassWord = findViewById(R.id.et_user_password);
    etUserName.addTextChangedListener(new TextWatcher() {
      @Override
      public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

      }

      @Override
      public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

      }

      @Override
      public void afterTextChanged(Editable editable) {

      }
    });
    etPassWord.addTextChangedListener(new MyTextWatcher());
    etAge.addTextChangedListener(new MyTextWatcher());
    etName.addTextChangedListener(new MyTextWatcher());
    years.add("1");
    branches.add("CSE");
    years.add("2");
    branches.add("ECE");
    years.add("3");
    branches.add("MAE");
    years.add("4");
    interests.addAll(Arrays.asList(Form_data.interests));
    ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this,
        R.layout.support_simple_spinner_dropdown_item, years);
    spinnerYear.setAdapter(yearAdapter);
    ArrayAdapter<String> branchesAdapter = new ArrayAdapter<>(this,
        R.layout.support_simple_spinner_dropdown_item, branches);
    spinnerBranch.setAdapter(branchesAdapter);
    ArrayAdapter<String> interestAdapter = new ArrayAdapter<>(this,
        R.layout.support_simple_spinner_dropdown_item, interests);
    spinnerInterest.setAdapter(interestAdapter);
    recyclerView = findViewById(R.id.pre_requisites_recyclerView);
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,
        LinearLayoutManager.VERTICAL, false);
    recyclerView.setLayoutManager(linearLayoutManager);
    for (int i = 0; i < Form_data.prerequisites.length; i++) {
      dataModelList.add(new PreRequisiteDataModel(Form_data.prerequisites[i], false));
    }
    adapter = new PreRequisiteAdapter(dataModelList, this);
    recyclerView.setAdapter(adapter);

    submitButton = findViewById(R.id.sign_up_button);
    submitButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        if (isFormOk()) {
          for (int i = 0; i < dataModelList.size(); i++) {
            if (dataModelList.get(i).isStatus()) {
              prereques.add(dataModelList.get(i).getText());
            }
          }
          String name = etName.getText().toString();
          String username = etUserName.getText().toString();
          String pass = etPassWord.getText().toString();
          String year = spinnerYear.getSelectedItem().toString();
          String interest = spinnerInterest.getSelectedItem().toString();
          String branch = spinnerBranch.getSelectedItem().toString();
          String age = etAge.getText().toString();
          Log.d("response", "prereques "+prereques.size());
          signUp(name, username, pass, age, year, branch, interest, prereques);
        }
      }
    });

  }


  private void signUp(String name, final String username, String pass, String age, String year,
      String branch, String interest, List<String> prerequisites) {
    Call<String> call = api
        .signup_user(name, pass, age, year, username, branch, prerequisites, interest);
    call.enqueue(new Callback<String>() {
      @Override
      public void onResponse(Call<String> call, Response<String> response) {
        if (response.isSuccessful()) {
          Log.d("response", response.body());
          PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).edit()
              .putString("user_name", username).apply();
          startActivity(new Intent(SignUpActivity.this, MainActivity.class));
          SignUpActivity.this.finish();
        }
      }

      @Override
      public void onFailure(Call call, Throwable t) {
        Log.d("response", t.toString());
      }
    });
  }


  private boolean isFormOk() {
    if (etName.getText().toString().isEmpty()) {
      etName.setError("Name is required");
      return false;
    } else if (etUserName.getText().toString().isEmpty()) {
      etUserName.setError("Username is required");
      return false;
    } else if (etPassWord.getText().toString().isEmpty()) {
      etPassWord.setError("Password is required");
      return false;
    } else if (etAge.getText().toString().isEmpty()) {
      etAge.setError("Age is required");
      return false;
    } else {
      return true;
    }
  }


  class MyTextWatcher implements TextWatcher {

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
      etName.setError(null);
      etAge.setError(null);
      etPassWord.setError(null);
    }

  }


  private void showMessage(String message) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
  }


}

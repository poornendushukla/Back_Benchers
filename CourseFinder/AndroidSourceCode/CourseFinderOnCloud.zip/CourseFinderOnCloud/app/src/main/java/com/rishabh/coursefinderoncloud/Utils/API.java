/*
 *  ***************************************************************
 *  Copyright 2018 Rishabh Shrivastava.
 *  ***************************************************************
 *
 *  API.java --
 *
 */

package com.rishabh.coursefinderoncloud.Utils;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface API {

  @FormUrlEncoded
  @POST("/LOGIN/")
  Call<String> login_user(@Field("username") String username,
      @Field("pass") String password);

  @FormUrlEncoded
  @POST("/SIGNUP/")
  Call<String> signup_user(@Field("name") String name,
      @Field("pass") String password,
      @Field("age") String age,
      @Field("year") String year,
      @Field("username") String username,
      @Field("subject") String subject,
      @Field("prereq") List<String> prereq,
      @Field("interest") String interest);

  /*@GET("/ItineraryData1/")
  Call<ArrayList<TileDataModel>> getItineraryData1(@Query("Email") String Email,
      @Query("page") int page);*/
}


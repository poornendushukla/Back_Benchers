package com.rishabh.coursefinderoncloud.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import com.rishabh.coursefinderoncloud.Activities.ViewCourseActitvity;
import com.rishabh.coursefinderoncloud.DataModels.CourseDataModel;
import com.rishabh.coursefinderoncloud.R;
import java.util.List;

public class CoursesRecyclerViewAdapter extends
    RecyclerView.Adapter<CoursesRecyclerViewAdapter.ViewHolder> {

  Context context;
  private List<CourseDataModel> tileDataModelList;

  public CoursesRecyclerViewAdapter(List<CourseDataModel> dataList, Context context) {
    this.tileDataModelList = dataList;
    this.context = context;
    setHasStableIds(true);
  }


  @NonNull
  @Override
  public CoursesRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    //inflate the layout file
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.course_list_tile, parent, false);
    return new CoursesRecyclerViewAdapter.ViewHolder(view);
  }


  @Override
  public long getItemId(int position) {
    return position;
  }


  @Override
  public void onBindViewHolder(@NonNull final CoursesRecyclerViewAdapter.ViewHolder holder, final int position) {
    final CourseDataModel courseDataModel = tileDataModelList.get(position);
    holder.courseAuthor.setText(String.format("by %s", courseDataModel.getAuthor()));
    holder.courseTitle.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        Intent intent = new Intent(context, ViewCourseActitvity.class);
        intent.putExtra("course_id", courseDataModel.getCourse_id());
        context.startActivity(intent);
      }
    });
    holder.upvotes.setText(String.format("%s", courseDataModel.getUpvotes()));
    holder.courseTitle.setText(courseDataModel.getName());
    RecyclerView recyclerView = holder.tagsRecyclerView;
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
    recyclerView.setLayoutManager(linearLayoutManager);
    List<String> tagsList = courseDataModel.getTagslist();
    TagListAdapter adapter = new TagListAdapter(tagsList, context);
    recyclerView.setAdapter(adapter);
  }


  @Override
  public int getItemCount() {
    return tileDataModelList.size();
  }


  public class ViewHolder extends RecyclerView.ViewHolder {

    TextView courseTitle, courseAuthor, upvotes;
    RecyclerView tagsRecyclerView;

    public ViewHolder(View view) {
      super(view);
      courseTitle = view.findViewById(R.id.title_course);
      courseAuthor = view.findViewById(R.id.author);
      upvotes = view.findViewById(R.id.no_upvotes);
      tagsRecyclerView = view.findViewById(R.id.tags_recyclerView);
    }

  }


  public void updateList(List<CourseDataModel> list){
    tileDataModelList = list;
    notifyDataSetChanged();
  }


}

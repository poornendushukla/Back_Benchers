package com.rishabh.coursefinderoncloud.Activities;

import static com.rishabh.coursefinderoncloud.Activities.SplashScreenActivity.api;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.rishabh.coursefinderoncloud.R;
import com.rishabh.coursefinderoncloud.Services.InternetService;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

  private EditText usernameEt, passET;
  private TextView signUpText;
  private Button loginButton;
  private Context context;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);
    context = LoginActivity.this;
    usernameEt = findViewById(R.id.et_user_name_number);
    passET = findViewById(R.id.et_user_password);
    usernameEt.addTextChangedListener(new TextWatcher() {
      @Override
      public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        usernameEt.setError(null);
      }

      @Override
      public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

      }

      @Override
      public void afterTextChanged(Editable editable) {

      }
    });
    passET.addTextChangedListener(new TextWatcher() {
      @Override
      public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        passET.setError(null);
      }

      @Override
      public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

      }

      @Override
      public void afterTextChanged(Editable editable) {

      }
    });
    passET = findViewById(R.id.et_user_password);
    signUpText = findViewById(R.id.sign_up_button);
    signUpText.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        singUp();
      }
    });
    loginButton = findViewById(R.id.login_button);
    loginButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        if (isFormOk()) {
          String user = usernameEt.getText().toString();
          String pass = passET.getText().toString();
          signIn(user, pass);
        }
      }
    });

  }


  private boolean isFormOk() {
    if (usernameEt.getText().toString().isEmpty()) {
      showMessage("Username empty");
      usernameEt.setError("username required");
      return false;
    } else if (passET.getText().toString().isEmpty()) {
      showMessage("Password empty");
      passET.setError("Password required");
      return false;
    } else {
      return true;
    }
  }


  private void showMessage(String message) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
  }


  private void signIn(final String username, String password) {
    Log.d("response", "in signIn function");
    Call<String> call = api
        .login_user(username,password);
    call.enqueue(new Callback<String>() {
      @Override
      public void onResponse(Call<String> call, Response<String> response) {
        if(response.isSuccessful()){
          Log.d("response", response.body());
          if(response.body().equals("success")){
            PreferenceManager.getDefaultSharedPreferences(LoginActivity.this).edit()
                .putString("user_name", username).apply();
            startActivity(new Intent(context, MainActivity.class));
            LoginActivity.this.finish();
          }else{
            showMessage(response.body());
          }
        }
      }

      @Override
      public void onFailure(Call call, Throwable t) {
        Log.d("response", t.toString());
      }
    });
  }


  private void singUp(){
    startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
  }


}
